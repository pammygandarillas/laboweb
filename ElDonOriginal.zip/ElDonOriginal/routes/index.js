var express = require('express');
var router = express.Router();

const mysql = require('mysql');
const db = mysql.createConnection({
  host: 'localhost',
  user: 'aileennag', // <-- Update this line with your username.
  database: 'c9'
});

db.connect((err) => {
  if (err) {
    console.error('Unable to connect to the database.');
    throw err;
  } else {
    console.log('Connected to the database.');
  }
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('indexCliente', { title: 'Express' });
});

router.get('/admin', function(req, res, next) {
  res.render('indexAdmin', { title: 'Express' });
  console.log("wow");
});

var nodemailer = require('nodemailer');

router.get('/login/:email/:pass', function (req, res) {
  //console.log("1 "+req.params.email);
  //console.log("2 "+req.params.pass);

  var email = req.params.email;
  var pass = req.params.pass
  
  //var emailcookies = req.cookies.email;
  //var passcookies = req.cookies.pass;
  // falta que no sea inyectable e implementar cookies
  db.query('select id_cliente,nombre,mail,password,teléfono,dirección from cliente where mail="'+email+'" and password="'+pass+'";'
  , (err, rows) =>{
  if(err){
    //console.log(err);
    res.status(500).json(err);
  }else{
    
    //console.log(rows);
    res.json(rows);
    
  }
 });
  //var email = req.cookies.email
  //var passwd = req.cookies.password
});


var rand,mailOptions,host,link;

router.post('/insertcliente', (req, res) =>{
    var nombre =req.body.nombre;
    var mail = req.body.email;
    var password = req.body.password;
    var telefono = req.body.telefono;
    var direccion = parseInt(req.body.direccion);
    console.log(nombre);
    console.log(mail);
    console.log(password);
    console.log(telefono);
    console.log(direccion);
    
    var cliente = { nombre: nombre, mail: mail, password: password, teléfono: telefono, dirección: direccion};
    
    db.query('INSERT INTO cliente SET ?', cliente, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{}
    });
});


router.get('/send',function(req,res){
  
        rand=Math.floor((Math.random() * 100) + 54);
	host=req.get('host');
	link="http://"+req.get('host')+"/verify?id="+rand;
	mailOptions={
		to : req.query.to,
		subject : "Please confirm your Email account",
		html : "Hello,<br> Please Click on the link to verify your email.<br><a href="+link+">Click here to verify</a>"	
	}
	
	
	console.log(mailOptions);
	smtpTransport.sendMail(mailOptions, function(error, response){
   	 if(error){
        	console.log(error);
		res.end("error");
	 }else{
        	console.log("Message sent: " + response.message);
		res.end("sent");
    	 }
});
});

router.get('/verify',function(req,res){
console.log(req.protocol+":/"+req.get('host'));
if((req.protocol+"://"+req.get('host'))==("http://"+host))
{
	console.log("Domain is matched. Information is from Authentic email");
	if(req.query.id==rand)
	{	
		console.log("email is verified");
		res.end("<h1>Email "+mailOptions.to+" is been Successfully verified");
	}
	else
	{
		console.log("email is not verified");
		res.end("<h1>Bad Request</h1>");
	}
}
else
{
	res.end("<h1>Request is from unknown source");
}
});

router.post('/insertpedido', (req, res) =>{
  
    console.log("hola");
    var id_cliente =req.body.id_cliente;
    var tipo_pedido = req.body.tipo_pedido;
    var tipo_pago = req.body.tipo_pago;
    var promocion = req.body.promocion;
    var total = parseInt(req.body.total);
    
    console.log(id_cliente);
    console.log(tipo_pedido);
    console.log(tipo_pago);
    console.log(promocion);
    console.log(total);
    
    var id_torta = req.body.detallePedido
    id_torta
    
    var pedido = {id_cliente: id_cliente, tipo_pedido: tipo_pedido, tipo_pago: tipo_pago, promocion: promocion, total: total};
    
    db.query('INSERT INTO pedido SET ?', pedido, (err, rows1) =>{
      console.log("Entré aquí al pinche menos.");
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
      console.log("INSERT PEDIDO SUCCEDED");

      
      req.body.detallePedido.forEach(ent=>{
      var detallePedido = { id_pedido: rows1.insertId, id_torta:ent.id_torta, cantidad: ent.cantidad};
        
            db.query('INSERT INTO torta_pedido SET ?', detallePedido, (err, rows2) =>{
              
          if(err){
            console.log(err);
            res.status(500).json(err);
          }else{
            console.log("Sí se insertó detalle pedido");
            //res.render('listo');
          }
        });
      
          console.log(JSON.stringify(ent));
          
        });
      
        res.render('listo');
      }
    });
});



router.post('/sendEmail', (req, res) =>{
    console.log("1");
    console.log("sendEmail fetched "+ req.body.email);
    console.log("3");
    rand = Math.floor(Math.random() * 10000) + 1  
    host=req.get('host');
    link="http://"+req.get('host')+"/verify?id="+rand;
    
    
    mailOptions={
      to : req.body.email,
      subject : "Tortas Don, confirmar cuenta",
      html : "Hola,<br> Introduce este código de validación para confirmar tu cuenta."+rand+"<br>"	
      
    };
    
    var transporter = nodemailer.createTransport('smtps://joud364%40gmail.com:joud3644@smtp.gmail.com');
      transporter.sendMail(mailOptions, function(error, info){
        if(error){
          return console.log(error);
        }
        console.log('Message sent: ' + info.response);
        
      });
});


router.post('/verifyEmail', (req, res) =>{
  
  var code = req.body.code;
  var mail = req.body.mail;
  console.log("rand "+ rand);
  console.log("llego el código "+code+" y correo: "+mail);
  
  if(code==rand){
    console.log("no mames ya la armaste");
    
    db.query('UPDATE cliente SET verificado = 1 WHERE mail = "'+mail+'";', (err, rows2) =>{
    if(err){
      console.log(err);
      res.status(500).json(err);
      
    }else{
      console.log("Sí se confirmó el mail");
      //res.render('listo');
      }
  });
  }else{
    console.log("no chingues");
  }
});


router.get('/top5', (req, res) =>{
    
    db.query('(select torta.descripcion, SUM(torta_pedido.cantidad) cantidad from torta, torta_pedido  where torta.id_torta = torta_pedido.id_torta group by torta.descripcion) order by cantidad desc limit 5;', (err, rows) =>{
    if(err){
      console.log(err);
      res.status(500).json(err);
      
    }else{
      console.log("TOP5!!!");
      res.json(rows);
      //res.render('listo');
      }
  });
  
});



/* *****************************************************************************                        Funcion Consultar Información
  *****************************************************************************/
router.get('/show/:table', function(req, res, next) {
  var info = req.params.table;

  if(info === 'Administrador'){
    db.query('select * from administrador', (err, rows) =>{
      if(err){
        res.status(500).json(err);
        console.log(err);
      }else{
        res.json(rows);
      }
    });
  }
  if(info === 'Tortas'){
    db.query('select * from torta', (err, rows) =>{
      if(err){
        res.status(500).json(err);
        console.log(err);
      }else{
        res.json(rows);
      }
    });
  }
  if(info === 'Ingrediente'){
    db.query('select * from ingrediente', (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.json(rows);
      }
    });
  }
  if(info === 'Cliente'){
    db.query('select * from cliente', (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.json(rows);
      }
    });
  }
  if(info === 'Direccion'){
    db.query('select * from direccion', (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.json(rows);
      }
    });
  }
  if(info === 'Ingrediente-Torta'){
    db.query('select * from ingrediente_torta', (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.json(rows);
      }
    });
  }
  if(info === 'Pedido'){
    db.query('select * from pedido', (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.json(rows);
      }
    });
  }
  if(info === 'Promocion'){
    db.query('select * from promocion', (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.json(rows);
      }
    });
  }
  if(info === 'Tarjeta-Credito'){
    db.query('select * from tarjeta_credito', (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.json(rows);
      }
    });
  }
  if(info === 'Torta-Pedido'){
    db.query('select * from torta_pedido', (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.json(rows);
      }
    });
  }

});

/* *****************************************************************************                        Funcion Insertar Información
  *****************************************************************************/
router.post('/insertAdministrador', (req, res) =>{
    var id_admin = parseInt(req.body.idadmin);
    var nombre =req.body.nombre;
    var mail = req.body.email;
    var password = req.body.password;

    var administrador = {id_administrador: id_admin, nombre: nombre, mail: mail, password: password};
    
    db.query('INSERT INTO administrador SET ?', administrador, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

router.post('/insertUser', (req, res) =>{
    var nombre =req.body.nombre;
    var mail = req.body.email;
    var password = req.body.password;
    var telefono = req.body.telefono;
    var direccion = parseInt(req.body.direccion);

    var cliente = {nombre: nombre, mail: mail, password: password, teléfono: telefono, dirección: direccion};
    
    db.query('INSERT INTO cliente SET ?', cliente, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

router.post('/insertDireccion', (req, res) =>{
    var calle =req.body.calle;
    var colonia = req.body.colonia;
    var numero = req.body.numero;
    var municipio = parseInt(req.body.municipio);

    var direccion = {calle: calle, colonia: colonia, numero: numero, municipio: municipio};
    
    db.query('INSERT INTO direccion SET ?', direccion, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

router.post('/insertPromocion', (req, res) =>{
    var descuento = parseInt(req.body.descuento);
    var descripcion = req.body.descripcion;
    var fecha = req.body.fecha;
    var id_cliente = parseInt(req.body.idcliente);

    var promocion = {descuento: descuento, descuento: descripcion, fecha_limite: fecha, id_cliente: id_cliente};
    
    db.query('INSERT INTO promocion SET ?', promocion, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

router.post('/insertPedido', (req, res) =>{
    var id_cliente = parseInt(req.body.idcliente);
    var tipo_pedido = parseInt(req.body.tipopedido);
    var tipo_pago = parseInt(req.body.pago);
    var promocion = parseInt(req.body.promocion);
    var total = parseFloat(req.body.total);

    var pedido = {id_cliente: id_cliente, tipo_pedido: tipo_pedido, tipo_pago: tipo_pago, promocio: promocion, total: total};
    
    db.query('INSERT INTO pedido SET ?', pedido, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

router.post('/insertTorta', (req, res) =>{
    var costo = parseInt(req.body.costo);
    var descripcion = req.body.descripcion;
    var foto = req.body.foto;
    var calificacion = parseInt(req.body.calificacion);

    var torta = {costo : costo , descripcion: descripcion, foto: foto, calificacion: calificacion};
    
    db.query('INSERT INTO torta SET ?', torta, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

router.post('/insertTortaPedido', (req, res) =>{
    var id_pedido = parseInt(req.body.idpedido);
    var id_torta = parseInt(req.body.idtorta);
    var cantidad = parseInt(req.body.cantidad);

    var torta_pedido = {id_pedido: id_pedido, id_torta: id_torta, cantidad: cantidad};
    
    db.query('INSERT INTO torta_pedido SET ?', torta_pedido, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

router.post('/insertIngrediente', (req, res) =>{
    var clasificacion =req.body.clasificacion;
    var descripcion = req.body.descripcion;
    var existencia = parseInt(req.body.existencia);
    var precio = parseInt(req.body.precio);

    var ingrediente = {clasificacion: clasificacion, descripcion: descripcion, existencia: existencia, precio : precio};
    
    db.query('INSERT INTO ingrediente SET ?', ingrediente, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

router.post('/insertIngredienteTorta', (req, res) =>{
    var id_ingrediente = parseInt(req.body.idingrediente);
    var id_torta = parseInt(req.body.idtorta);

    var ingrediente_torta = {id_ingrediente: id_ingrediente, id_torta: id_torta };
    
    db.query('INSERT INTO ingrediente_torta SET ?', ingrediente_torta, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

router.post('/insertTarjeta', (req, res) =>{
    var id_cliente = parseInt(req.body.idcliente);
    var nombre = req.body.nombre;
    var num_tarjeta = req.body.numtarjeta;
    var vigencia = req.body.vigencia;
    

    var tarjeta_credito = {id_cliente: id_cliente, nombre: nombre, numero_tarjeta: num_tarjeta, vigencia: vigencia};
    
    db.query('INSERT INTO tarjeta_credito SET ?', tarjeta_credito, (err, rows) =>{
      if(err){
        console.log(err);
        res.status(500).json(err);
      }else{
        res.render('listo');
      }
    });
});

/* *****************************************************************************                        Funcion Modificar Información
  *****************************************************************************/
router.post('/updateAdministrador', (req, res) =>{
    var id_admin = parseInt(req.body.idadmin);
    var password = req.body.password;
    
    db.query('UPDATE administrador SET ? WHERE id_administrador = ?', [{ password: password}, id_admin], (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoUpdate');
      }
    });
});


router.post('/updateTorta', (req, res) =>{
    var costo = parseInt(req.body.costo);
    var descripcion = req.body.descripcion;
    
    db.query('UPDATE torta SET ? WHERE descripcion = ?', [{ costo: costo}, descripcion], (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoUpdate');
      }
    });
});

router.post('/updateIngrediente', (req, res) =>{
    var id_ingrediente = parseInt(req.body.idingrediente);
    var existencia = req.body.existencia;
    
    db.query('UPDATE ingrediente SET ? WHERE id_ingrediente = ?', [{ existencia: existencia}, id_ingrediente], (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoUpdate');
      }
    });
});


/* *****************************************************************************                        Funcion Borrar Información
  *****************************************************************************/
router.post('/deleteAdministrador', (req, res) =>{
    var id_administrador = parseInt(req.body.idadmin);
    
    db.query('DELETE FROM administrador WHERE id_administrador = ? ', id_administrador, (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoDelete');
      }
    });
});


router.post('/deleteCliente', (req, res) =>{
    var id_cliente = parseInt(req.body.idcliente);
    
    db.query('DELETE FROM cliente WHERE id_cliente = ? ', id_cliente, (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoDelete');
      }
    });
});

router.post('/deleteDireccion', (req, res) =>{
    var id_direccion = parseInt(req.body.iddireccion);
    
    db.query('DELETE FROM direccion WHERE id_direccion = ? ', id_direccion, (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoDelete');
      }
    });
});

router.post('/deletePromocion', (req, res) =>{
    var id_promocion = parseInt(req.body.idpromocion);
    
    db.query('DELETE FROM promocion WHERE id_promocion = ? ', id_promocion, (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoDelete');
      }
    });
});

router.post('/deletePedido', (req, res) =>{
    var id_pedido = parseInt(req.body.idpedido);
    
    db.query('DELETE FROM pedido WHERE id_pedido = ? ', id_pedido, (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoDelete');
      }
    });
});

router.post('/deleteTorta', (req, res) =>{
    var id_torta = parseInt(req.body.idtorta);
    
    db.query('DELETE FROM torta WHERE id_torta = ? ', id_torta, (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoDelete');
      }
    });
});

router.post('/deleteIngrediente', (req, res) =>{
    var id_ingrediente = parseInt(req.body.idingrediente);
    
    db.query('DELETE FROM ingrediente WHERE id_ingrediente = ? ', id_ingrediente, (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoDelete');
      }
    });
});

router.post('/deleteTarjeta', (req, res) =>{
    var id_cliente = parseInt(req.body.idcliente);
    
    db.query('DELETE FROM tarjeta_credito WHERE id_cliente = ? ', id_cliente, (err, rows) =>{
      if(err){
        res.status(500).json(err);
      }else{
        res.render('listoDelete');
      }
    });
});

/* *****************************************************************************                            Queries Graficas
  *****************************************************************************/

router.get('/showGraphTortas', function(req, res, next) {
  db.query('(select torta.descripcion, SUM(torta_pedido.cantidad) cantidad from torta, torta_pedido  where torta.id_torta = torta_pedido.id_torta group by torta.descripcion) order by cantidad desc limit 5', (err, rows) =>{
    if(err){
      res.status(500).json(err);
      console.log(err);
    }else{
      res.json(rows);
    }
  });
});







module.exports = router;

