/*global angular*/
'use strict';

angular.module('myApp', ['myApp.controllers','ngRoute']);

angular.module('myApp').config(function($routeProvider, $locationProvider){        
	$routeProvider.when('/view1',{            
		controller:'loginController',templateUrl:'/partials/login.ejs'        
	}).when('/view2/',{            
		controller: 'Controller2',templateUrl: '/partials/view2.html'        
	}).when('/view3/',{            
		controller: 'MyCtrl1',templateUrl: '/partials/view3.html'        
	}).when('/login/',{            
		controller: 'Controller1',templateUrl: '/partials/view1.ejs'        
	}).when('/confirm/',{            
		controller: 'confirmController',templateUrl: '/partials/confirm.ejs'        
	})
	.otherwise({redirectTo:'/view1'});     
	$locationProvider.html5Mode(true); //activate HTML5 Mode 
});