/*global myApp*/
/*global angular*/

angular.module('myApp').factory('myService', function($http) {
  var myService = {
    async: function() {
      var promise = $http.get('/show').then(function (response) {
        return response.data;
      });
      return promise;
    }
  };
  return myService;
});


angular.module('myApp.controllers', []).controller(
	'ControllerIndex' ,function($scope,$location,myService){
	   alert("hello!!");
		myService.async().then(function(d) {
    		$scope.data = d;
		});
});