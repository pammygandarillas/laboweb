/*global angular*/
'use strict';

angular.module('myApp', ['myApp.controllers']);

/*angular.module('myApp').config(function($routeProvider, $locationProvider){        
	$routeProvider.when('/showTable',{            
		controller:'ShowController',templateUrl:'/partials/show.ejs'        
	}).otherwise({redirectTo:'/index'});     
	$locationProvider.html5Mode(true); //activate HTML5 Mode 
});*/