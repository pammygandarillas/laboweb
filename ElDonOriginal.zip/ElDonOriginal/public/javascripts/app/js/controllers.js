/*global myApp*/
/*global angular*/
'use strict';


angular.module('myApp').service('top',function($http){
	alert("entré al servicio");
	var user = this.async=function(){
		var promise = $http.get('/top5').then(function (response) {
				return response.data;
			});
			return promise;
	}

});

angular.module('myApp').service('sendEmail',function($http){
	

	var user = this.async=function(email){
		alert(email);
		var promise = $http.post('/sendEmail',{email:email}).then(function (response) {
			//var userFetched = response.data[0];
	        
				return response.data;
			});
			return promise;
	}

});


angular.module('myApp').service('verifyEmail',function($http){

	var user = this.async=function(confirm){
		
		var promise = $http.post('/verifyEmail',confirm).then(function (response) {
	        
				return response.data;
			});
			return promise;
	}

});

angular.module('myApp').service('loginService',function($http){
	
	var id_cliente;
	var nombre;
	var mail;
	var password;
	var telefono;
	var direccion;
	
	var user = this.async=function(loginData){
		var promise = $http.get('/login/'+loginData.email+"/"+loginData.pass).then(function (response) {
			var userFetched = response.data[0];
			nombre = userFetched.nombre;
			mail = userFetched.mail;
	        id_cliente = userFetched.id_cliente;
	        
				return userFetched;
			});
			return promise;
	}
	
	this.getNombre=function(){
		//alert("valueAdquired");
		return nombre;
	}
	
	this.getMail=function(){
		//alert("valueAdquired");
		return mail;
	}
	
	this.getIDcliente=function(){
		//alert("valueAdquired");
		return id_cliente;
	}
	
	this.logged=function(){
		if((nombre === undefined)&&(mail === undefined)){
			return false;
		}else{
			return true;
		}
	}
	
	this.logout=function(){
		
	}
});

angular.module('myApp').factory('myService', function($http) {
  var myService = {
    async: function(tabla) {
      var promise = $http.get('/show/'+tabla).then(function (response) {
        return response.data;
      });
      return promise;
    }
  };
  console.log("111service "+myService);
  return myService;
});

angular.module('myApp').factory('insertcliente', function($http) {
  var myService = {
    async: function(usuario) {
      var promise = $http.post('/insertcliente', usuario).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('insertPedido', function($http) {
  var myService = {
    async: function(pedido) {
    	
      var promise = $http.post('/insertpedido', pedido).then(function (response) {
        return response;
      });
      return promise;
    }
  };
  return myService;
});

google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(function () {
    angular.bootstrap(document.body, ['myApp']);
});

angular.module('myApp.controllers', []).
  controller('MyCtrl1', ['$scope','top',function($scope,top) {
  	
  	
  	top.async().then(function(d) {
  		
  		
  		
  		var biArr = [];
  		var i;
  	    for (i = 0; i < 5; i++) {
  	    	var arr = [];
  	    	arr.push(d[i].descripcion);
  	    	arr.push(d[i].cantidad);
  	        biArr.push(arr);	
  	    }
  	    
  	    alert(biArr);
  		

	var data = new google.visualization.DataTable();
        data.addColumn('string', 'Topping');
        data.addColumn('number', 'Slices');
        data.addRows(biArr);
	var options = {
          title: 'Las 5 más pedidas'
        };
        var chart = new google.visualization.ColumnChart(document.getElementById('chartdiv'));
        chart.draw(data, options);
	  
  	});
  	
  	//var data = {"2013-01-21":1,"2013-01-22":7};

  }]).controller(
	'Controller1',function($scope,$location,myService,loginService,insertPedido){
	    //Set some variable
	    
		$scope.modal = {}
		$scope.cart = {}
		$scope.cart.items = []
		$scope.cart.total = 0;
		$scope.delivery = {};
		//$scope.email = globalVariable.email;
		$scope.cardnumber = /^\d+$/;
		$scope.expired = /[0-9]{4}\/[0-9]{2}/
	    myService.async("Tortas").then(function(d) {
        
	      $scope.data = d;
	    });
	    
	    $scope.addToCart = function (item) {
	    	
	    	var length = $scope.cart.items.length;

	    	if($scope.cart.items.length === 0){

	    		item.cantidad=1;
	    		$scope.cart.items.push(item);
	    	}else{
	    		var i;
	    		var duplicado = false;
	    		for (i = 0; i < length; i++) {

	    			if($scope.cart.items[i].descripcion === item.descripcion){

	    				$scope.cart.items[i].cantidad++;

	    				duplicado = true;

	    				break;
	    				
	    			}else{

	    			}
	    		}
	    		if(duplicado){

	    		}else{
	    			item.cantidad=1;
	    			$scope.cart.items.push(item);
	    		}
	    	}

			$scope.cart.total = parseInt($scope.cart.total) + parseInt(item.costo);

	    };
		
		$scope.showModal=function(){
			if(loginService.logged()){
			
				var pedido={};
			    pedido.id_cliente = loginService.getIDcliente();
				pedido.tipo_pedido=0;
			    pedido.tipo_pago=0;
			    pedido.promocion=null;
			    pedido.total=$scope.cart.total;
			    pedido.detallePedido=$scope.cart.items;
			    	
				insertPedido.async(pedido).then(function(d) {

				});
				
			}else{
				$location.path('/login');
			}
		}
		
		//function to remove element to cart and update amount of price
		$scope.removeToCart = function (item) {
			var index = $scope.cart.items.indexOf(item);
			
			
			
			if (index >= 0) {
				if($scope.cart.items[index].cantidad===1){
					$scope.cart.total = parseInt($scope.cart.total) - parseInt($scope.cart.items[index].costo);
					$scope.cart.items.splice(index, 1);		
				}else{
					$scope.cart.items[index].cantidad--;
					$scope.cart.total = parseInt($scope.cart.total) - parseInt($scope.cart.items[index].costo);
				}
			}
			if (!$scope.cart.items.length) {
				$scope.cart = {};
				$scope.cart.items = []
				$scope.cart.total = 0;
			}
		}		
		
	    
	    
	}).controller('Controller2',function($scope,insertcliente){
		$scope.insertCliente=function(){
			insertcliente.async($scope.user).then(function(d) {
	    });
		};
	}).controller('confirmController',function($scope,loginService,sendEmail,verifyEmail){
		$scope.email = loginService.getMail();
		
		$scope.sendEmail=function(){
			
			
			sendEmail.async($scope.email).then(function(d) {
				
			});
		};	
		
		$scope.verifyEmail=function(){
			alert("trying to verify");
		    var confirm = {};
		    confirm.code = $scope.code;
			confirm.mail = $scope.email;
			
			verifyEmail.async(confirm).then(function(d) {
				
			});
		}
	
	}).controller('Controller3',function($scope,$routeParams,myService,loginService){
	  $scope.test5 = loginService.getNombre();
	  $scope.selectTable=function(selectedItemvalue){
	    myService.async(selectedItemvalue).then(function(d) {
	    	$scope.data = d;
	    });
	  };
	}
).controller('loginController',function($rootScope,$scope,$routeParams,loginService,$location){
	
  $scope.login=function(){
  	        $location.path('/admin');
			loginService.async($scope.login).then(function(d) {
			$rootScope.nombreUsuario = "Hola, "+loginService.getNombre();
			$location.path('/view1');
	
	    });
  };
}).controller('Controller10', [],
	function MenuCtrl($scope, $http, $stamplay, userStatus, restaurant, globalVariable, paramValue,myService) {

	    alert("please");
	    	    myService.async("Tortas").then(function(d) {

          alert("success");	      $scope.data = d;
	    });

		//Call service
		//if user was defined -> update $scope
		var user = userStatus.getUserModel()
		user.currentUser()
			.then(function(res){
				var user = res.user;
				var logged = user._id;
				if(logged !== undefined){
						$scope.user = {};
						$scope.user.logged = true;
						$scope.user.displayName = user.displayName;
						$scope.user.picture = user.profileImg;
						$scope.user._id = user._id;
						userStatus.setUser(user.displayName, user.profileImg, user._id, user.email, true)
						getRestaurant(paramValue, false)
				}else{
						getRestaurant(paramValue, true)
				}
			}, function(){
				getRestaurant(paramValue, true)
			})
		//function for get Restaurant by id

		function getRestaurant(paramValue, notlogged) {
			var model = restaurant.get();
			model.get({"_id" : paramValue})
				.then(function(model){
					$scope.$apply(function(){
						$scope.restaurant = model.data[0];
						var meal_ids = model.data[0].meals;
						var meals = [];
						for(var i = 0; i < meal_ids.length; i += 1) {
							Stamplay.Object("meal")
								.get({ _id : meal_ids[i] })
									.then(function(res) {
										meals.push(res.data[0]);
											$scope.$apply();
									})
						}


						$scope.restaurant.menuItems = meals;
						var find = true;
						if (!notlogged) {
							for (var i = 0; i < $scope.restaurant.actions.ratings.users.length && find; i++) {
								if ($scope.restaurant.actions.ratings.users[i].userId == $scope.user._id) {
									$scope.yourvote = $scope.restaurant.actions.ratings.users[i].rating
									$scope.voted = true;
									find = false;
								}
							}
						}
					})
				},function(){
					$scope.error = 'Ops something went wrong'
				})
		}

		//Set some variable
		$scope.modal = {}
		$scope.cart = {}
		$scope.cart.items = []
		$scope.cart.total = 0;
		$scope.card = {};
		$scope.delivery = {};
		$scope.email = globalVariable.email;
		$scope.cardnumber = /^\d+$/;
		$scope.expired = /[0-9]{4}\/[0-9]{2}/

		//function to add element to cart and update amount of price
		$scope.addToCart = function (item) {
			$scope.cart.items.push(item)
			$scope.cart.total = parseInt($scope.cart.total) + parseInt(item.price);
		}.price.price.price

		//function to remove element to cart and update amount of price
		$scope.removeToCart = function (item) {
			var index = $scope.cart.items.indexOf(item);
			if (index >= 0) {
				$scope.cart.total = parseInt($scope.cart.total) - parseInt($scope.cart.items[index].price);
				$scope.cart.items.splice(index, 1);
			}
			if (!$scope.cart.items.length) {
				$scope.cart = {};
				$scope.cart.items = []
				$scope.cart.total = 0;
			}
		}

		//function for show or hide modal
		$scope.showModal = function () {
			globalVariable.showModal('#checkoutModal')
		}
		$scope.dismiss = function () {
			globalVariable.hideModal('#paymentModal')
		}

		//function for checkout order
		$scope.checkout = function (restaurant) {
			//check if all field are not empty
			if (Object.keys($scope.card).length != 4 || Object.keys($scope.delivery).length != 4) {
				$scope.modal.error = 'All fields are required'
			} else {
				//create an order
				var meals = []
				for (var i = 0; i < $scope.cart.items.length; i++) {
					meals.push($scope.cart.items[i].name)
				}
				var orderContents = {
					email : $scope.delivery.email,
					surname : $scope.delivery.surname,
					address : $scope.delivery.address,
					notes : $scope.delivery.notes,
					meals : meals,
					price : $scope.cart.total,
					delivered : false
				}

				var order = Stamplay.Object('order');

				order.save(orderContents).then(function(){
					globalVariable.hideModal('#checkoutModal')
					$scope.$apply(function(){
						$scope.cart = {};
				 		$scope.cart.items = []
				 		$scope.cart.total = 0;
					})
					var webhook = Stamplay.Webhook('ordercomplete');
					var data = {
							restaurant_owner_email: restaurant.owner_email,
							order: data
					}
					webhook.post(data).then(function (response) {}, function( err ){
					  $scope.modal.error = 'Ops Something went Wrong'
					});
					setTimeout(function () {
						globalVariable.showModal('#paymentModal')
					}, 1000)

				}, function(){
					$scope.modal.error = 'Ops Something went Wrong'
				})
			}
		}
});


angular.module('myApp').service('itemSelectionService', function($http) {
	
	var itemSelected = undefined;
	
	this.setSelection=function(s){
		//alert("valueChanged");
		this.itemSelected = s;
	}
	
	this.getSelection=function(){
		//alert("valueAdquired");
		return this.itemSelected;
	}
  
});


/*
angular.module('myApp').factory('loginService', function($http) {
	var damn;
	var myService = {
		async: function(login) {
			var promise = $http.get('/login/'+login.email+"/"+login.pass).then(function (response) {
				return response;
			});
			return promise;
		}
	};
	
	alert("my sERVICE! "+myService);
  return myService;
});
*/




