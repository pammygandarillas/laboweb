/*global angular*/
'use strict';

angular.module('myApp', ['myApp.controllers','ngRoute','zingchart-angularjs']);

angular.module('myApp').config(function($routeProvider, $locationProvider){
	$routeProvider.when('/principal',{            
		controller:'Controller1',templateUrl:'/partials/principal.html'        
	}).when('/view2/',{            
		controller: 'Controller2',templateUrl: '/partials/view2.html'        
	}).when('/consultar/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/consultar.html'  
	}).when('/graficas/',{            
		controller: 'BarCtrl',templateUrl: '/partials/graficas.html'
	
	
		//CONSULTAR
	}).when('/consultaTorta/',{  
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaTorta.html' 
	}).when('/consultaAdministrador/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaAdministrador.html' 
	}).when('/consultaIngrediente/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaIngrediente.html'
	}).when('/consultaCliente/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaCliente.html'
	}).when('/consultaDireccion/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaDireccion.html'
	}).when('/consultaIngredienteTorta/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaIngredienteTorta.html'
	}).when('/consultaPedido/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaPedido.html'
	}).when('/consultaPromocion/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaPromocion.html'
	}).when('/consultaTarjetaCredito/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaTarjetaCredito.html'
	}).when('/consultaTortaPedido/',{            
		controller: 'controllerConsultar',templateUrl: '/partials/Consultar/consultaTortaPedido.html'
		
		//INSERTAR
	}).when('/insertarAdministrador/',{            
		controller: 'insertadministrador',templateUrl: '/partials/Insertar/insertarAdministrador.html'
	}).when('/insertarCliente/',{            
		controller: 'insertarcliente',templateUrl: '/partials/Insertar/insertarCliente.html'
	}).when('/insertarIngrediente/',{            
		controller: 'insertaringrediente',templateUrl: '/partials/Insertar/insertarIngrediente.html'
	}).when('/insertarPromocion/',{            
		controller: 'insertarpromocion',templateUrl: '/partials/Insertar/insertarPromocion.html'
	}).when('/insertarTorta/',{            
		controller: 'insertartorta',templateUrl: '/partials/Insertar/insertarTorta.html'
		
		//MODIFICAR
	}).when('/modificarAdministrador/',{            
		controller: 'modificaradministrador',templateUrl: '/partials/Modificar/modificarAdministrador.html'
	}).when('/modificarTorta/',{            
		controller: 'modificartorta',templateUrl: '/partials/Modificar/modificarTorta.html'
	}).when('/modificarIngrediente/',{            
		controller: 'modificaringrediente',templateUrl: '/partials/Modificar/modificarIngrediente.html'
		
		//BORRAR
	}).when('/borrarTorta/',{  
		controller: 'borrartorta',templateUrl: '/partials/Borrar/borrarTorta.html' 
	}).when('/borrarAdministrador/',{            
		controller: 'borraradministrador',templateUrl: '/partials/Borrar/borrarAdministrador.html' 
	}).when('/borrarIngrediente/',{            
		controller: 'borraringrediente',templateUrl: '/partials/Borrar/borrarIngrediente.html'
	}).when('/borrarCliente/',{            
		controller: 'borrarcliente',templateUrl: '/partials/Borrar/borrarCliente.html'
	}).when('/borrarDireccion/',{            
		controller: 'borrardireccion',templateUrl: '/partials/Borrar/borrarDireccion.html'
	}).when('/borrarTarjetaCredito/',{            
		controller: 'borrartarjetacredito',templateUrl: '/partials/Borrar/borrarTarjetaCredito.html'
	}).when('/borrarPedido/',{            
		controller: 'borrarpedido',templateUrl: '/partials/Borrar/borrarPedido.html'
	}).when('/borrarPromocion/',{            
		controller: 'borrarpromocion',templateUrl: '/partials/Borrar/borrarPromocion.html'
	}).otherwise({redirectTo:'/principal'});     
	$locationProvider.html5Mode(true); //activate HTML5 Mode 
});