/*global myApp*/
/*global angular*/

'use strict';

/* *****************************************************************************                              SERVICES
  *****************************************************************************/
angular.module('myApp').service('itemSelectionService', function($http) {
	var itemSelected = undefined;
	
	this.setSelection=function(s){
		//alert("valueChanged");
		this.itemSelected = s;
	}
	
	this.getSelection=function(){
		//alert("valueAdquired");
		return this.itemSelected;
	};
  
});

/* *****************************************************************************                                 FACTORIES
  *****************************************************************************/
//GRAFICAS
angular.module('myApp').factory('tortasGraph', function($http) {
  var myService = {
    async: function(tabla) {
      var promise = $http.get('/showGraphTortas').then(function (response){
        return response.data;
      });
      return promise;
    }
  };
  return myService;
});


//CONSULTAR
angular.module('myApp').factory('myService', function($http) {
  var myService = {
    async: function(tabla) {
      var promise = $http.get('/show/'+tabla).then(function (response){
        return response.data;
      });
      return promise;
    }
  };
  return myService;
});

//INSERTAR
angular.module('myApp').factory('insertadministrador', function($http) {
  var myService = {
    async: function(admin) {
      var promise = $http.post('/insertAdministrador', admin).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('insertcliente', function($http) {
  var myService = {
    async: function(usuario) {
      var promise = $http.post('/insertUser', usuario).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('insertingrediente', function($http) {
  var myService = {
    async: function(ingrediente) {
      var promise = $http.post('/insertIngrediente', ingrediente).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('insertpromocion', function($http) {
  var myService = {
    async: function(promo) {
      var promise = $http.post('/insertPromocion', promo).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('inserttorta', function($http) {
  var myService = {
    async: function(torta) {
      var promise = $http.post('/insertTorta', torta).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});


//BORRAR
angular.module('myApp').factory('borraradministrador', function($http) {
  var myService = {
    async: function(admin) {
      var promise = $http.post('/deleteAdministrador', admin).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});


angular.module('myApp').factory('borrarcliente', function($http) {
  var myService = {
    async: function(usuario) {
      var promise = $http.post('/deleteCliente', usuario).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('borrardireccion', function($http) {
  var myService = {
    async: function(direccion) {
      var promise = $http.post('/deleteDireccion', direccion).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('borraringrediente', function($http) {
  var myService = {
    async: function(ingrediente) {
      var promise = $http.post('/deleteIngrediente', ingrediente).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('borrarpedido', function($http) {
  var myService = {
    async: function(pedido) {
      var promise = $http.post('/deletePedido', pedido).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('borrarpromocion', function($http) {
  var myService = {
    async: function(promocion) {
      var promise = $http.post('/deletePromocion', promocion).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('borrartorta', function($http) {
  var myService = {
    async: function(torta) {
      var promise = $http.post('/deleteTorta', torta).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('borrartarjetacredito', function($http) {
  var myService = {
    async: function(tarjeta) {
      var promise = $http.post('/deleteTarjeta', tarjeta).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

//MODIFICAR
angular.module('myApp').factory('modificaradministrador', function($http) {
  var myService = {
    async: function(admin) {
      var promise = $http.post('/updateAdministrador', admin).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('modificartorta', function($http) {
  var myService = {
    async: function(torta) {
      var promise = $http.post('/updateTorta', torta).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

angular.module('myApp').factory('modificaringrediente', function($http) {
  var myService = {
    async: function(ingrediente) {
      var promise = $http.post('/updateIngrediente', ingrediente).then(function (response) {
      	alert(response);
        return response;
      });
      return promise;
    }
  };
  return myService;
});

/* *****************************************************************************                               CONTROLLERS
  *****************************************************************************/

angular.module("myApp.controllers", ["zingchart-angularjs"]).controller("BarCtrl", function ($scope) {
	  $scope.myJson = {
      type : "bar",
      title:{
        backgroundColor : "transparent",
        fontColor :"black",
        text : "Hello world"
      },
      backgroundColor : "white",
      series : [
        {
          values : [1,2,3,4],
          backgroundColor : "#4DC0CF"
        }
      ]
    };
  
  $scope.addValues = function(){
    var val = Math.floor((Math.random() * 10));
    console.log(val);
    $scope.myJson.series[0].values.push(val);
  }
});

angular.module('myApp.controllers', []).controller('insertadministrador',function($scope,$location,insertadministrador){
		$scope.insertAdmin=function(){
			alert("Informacion Insertada");
			$location.path('/insertarCliente'); 
			insertadministrador.async($scope.admin).then(function(d){
	    });
		};
	}).controller('insertarcliente',function($scope,insertcliente,$location){
		$scope.insertCliente=function(){
			alert("Informacion Insertada");
			$location.path('/insertarCliente'); 
			insertcliente.async($scope.user).then(function(d){
	    	});
		};
	}).controller('insertaringrediente',function($scope,insertingrediente,$location){
		$scope.insertIngrediente=function(){
			alert("Informacion Insertada");
			$location.path('/insertarIngrediente'); 
			insertingrediente.async($scope.ingrediente).then(function(d){
	    	});
		};
	}).controller('insertarpromocion',function($scope,insertpromocion,$location){
		$scope.insertPromocion=function(){
			alert("Informacion Insertada");
			$location.path('/insertPromocion'); 
			insertpromocion.async($scope.promo).then(function(d){
	    	});
		};
	}).controller('insertartorta',function($scope,inserttorta,$location){
		$scope.insertTorta=function(){
			alert("Informacion Insertada");
			$location.path('/insertarTorta'); 
			inserttorta.async($scope.torta).then(function(d){
	    });
		};
	}).controller('borraradministrador',function($scope,borraradministrador,$location){
		$scope.borrarAdministrador=function(){
			alert("Informacion Borrada");
	    	$location.path('/borrarAdministrador'); 
			borraradministrador.async($scope.admin).then(function(d) {
	    	});
		};
	}).controller('borrarcliente',function($scope,borrarcliente,$location){
		$scope.borrarCliente=function(){
			alert("Informacion Borrada");
	    	$location.path('/borrarCliente'); 
			borrarcliente.async($scope.user).then(function(d) {
	    	});
		};
	}).controller('borraringrediente',function($scope,borraringrediente,$location){
		$scope.borrarIngrediente=function(){
			alert("Informacion Borrada");
	    	$location.path('/borrarIngrediente'); 
			borraringrediente.async($scope.ingrediente).then(function(d) {
	    	});
		};
	}).controller('borrarpedido',function($scope,borrarpedido,$location){
		$scope.borrarPedido=function(){
			alert("Informacion Borrada");
	    	$location.path('/borrarPedido'); 
			borrarpedido.async($scope.pedido).then(function(d) {
	    	});
		};
	}).controller('borrardireccion',function($scope,borrardireccion,$location){
		$scope.borrarDireccion=function(){
			alert("Informacion Borrada");
	    	$location.path('/borrarDireccion'); 
			borrardireccion.async($scope.direccion).then(function(d) {
	    	});
		};
	}).controller('borrarpromocion',function($scope,borrarpromocion,$location){
		$scope.borrarPromocion=function(){
			alert("Informacion Borrada");
	    	$location.path('/borrarPromocion'); 
			borrarpromocion.async($scope.promo).then(function(d) {
	    	});
		};
	}).controller('borrartorta',function($scope,borrartorta,$location){
		$scope.borrarTorta=function(){
			alert("Informacion Borrada");
	    	$location.path('/borrarTorta'); 
			borrartorta.async($scope.torta).then(function(d) {
	    	});
		};
	}).controller('borrartarjetacredito',function($scope,borrartarjetacredito,$location){
		$scope.borrarTarjetaCredito=function(){
			alert("Informacion Borrada");
	    	$location.path('/borrarTarjetaCredito'); 
			borrartarjetacredito.async($scope.tarjeta).then(function(d) {
	    	});
		};
	}).controller('modificaradministrador',function($scope,modificaradministrador,$location){
		$scope.updateAdmin=function(){
			alert("Informacion Modificada");
	    $location.path('/modificarAdministrador'); 
			modificaradministrador.async($scope.admin).then(function(d) {
	    	});
		};
	}).controller('modificaringrediente',function($scope,modificaringrediente,$location){
		$scope.updateIngrediente=function(){
			alert("Informacion Modificada");
	    $location.path('/modificarIngrediente'); 
			modificaringrediente.async($scope.ingrediente).then(function(d) {
	    	});
		};
	}).controller('modificartorta',function($scope,modificartorta,$location){
		$scope.updateTorta=function(){
			alert("Informacion Modificada");
	    $location.path('/modificarTorta'); 
			modificartorta.async($scope.torta).then(function(d) {
	    	});
		};
	}).controller('controllerConsultar',function($scope,$routeParams,$location,myService,itemSelectionService){
		if(itemSelectionService.itemSelected){
			myService.async(itemSelectionService.itemSelected).then(function(d){
	        $scope.data = d;
	      });
		}

	  $scope.selectTable=function(selectedItemvalue){
	    if(selectedItemvalue === 'Tortas'){
	    	itemSelectionService.setSelection(selectedItemvalue)
	    	$location.path('/consultaTorta');
	    }
	    
	    if(selectedItemvalue === 'Administrador'){
	    	itemSelectionService.setSelection(selectedItemvalue)
	    	$location.path('/consultaAdministrador');
	    }
	    
	    if(selectedItemvalue === 'Ingrediente'){
	    	itemSelectionService.setSelection(selectedItemvalue);
	    	$location.path('/consultaIngrediente'); 
	    }
	    if(selectedItemvalue === 'Cliente'){
	    	itemSelectionService.setSelection(selectedItemvalue);
	      $location.path('/consultaCliente'); 

	    }
	    if(selectedItemvalue === 'Direccion'){
	    	itemSelectionService.setSelection(selectedItemvalue);
	        $location.path('/consultaDireccion'); 
	    }
	    if(selectedItemvalue === 'Ingrediente-Torta'){
	    	itemSelectionService.setSelection(selectedItemvalue);
	        $location.path('/consultaIngredienteTorta'); 
	    }
	    if(selectedItemvalue === 'Pedido'){
	    	itemSelectionService.setSelection(selectedItemvalue);
	        $location.path('/consultaPedido'); 
	    }
	    if(selectedItemvalue === 'Promocion'){
	    	itemSelectionService.setSelection(selectedItemvalue);
	        $location.path('/consultaPromocion'); 
	      
	    }
	    if(selectedItemvalue === 'Tarjeta-Credito'){
	    	itemSelectionService.setSelection(selectedItemvalue);
	        $location.path('/consultaTarjetaCredito'); 
	      
	    }
	    if(selectedItemvalue === 'Torta-Pedido'){
	    	itemSelectionService.setSelection(selectedItemvalue);
	        $location.path('/consultaTortaPedido'); 
	    }
	  } 
	});