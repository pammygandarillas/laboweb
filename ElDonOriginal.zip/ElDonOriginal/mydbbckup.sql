-- MySQL dump 10.13  Distrib 5.7.10, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.7.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administrador` (
  `id_administrador` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `mail` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id_administrador`),
  UNIQUE KEY `mail_UNIQUE` (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
INSERT INTO `administrador` VALUES (1,'admin','admin@tortasdon.mx','soyElAdmin');
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `password` varchar(45) DEFAULT NULL,
  `teléfono` varchar(45) DEFAULT NULL,
  `dirección` int(11) NOT NULL,
  PRIMARY KEY (`id_cliente`),
  UNIQUE KEY `mail_UNIQUE` (`mail`),
  KEY `fk_promocion_direccion_idx` (`dirección`),
  CONSTRAINT `fk_promocion_direccion` FOREIGN KEY (`dirección`) REFERENCES `direccion` (`id_direccion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Isabel Sanchez','isa.san@gmail.com','Isa83','53974376',1),(2,'Hector Ibarra','hector.iba@hotmail.com','comidarica','53781212',2),(3,'Alonso Scherer','scherer.a@gmail.com','fuiAEuropa','53657232',3),(4,'Lucia Nieto','lucynieto@gmail.com','quieroTorta','26539808',4);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `direccion`
--

DROP TABLE IF EXISTS `direccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `direccion` (
  `id_direccion` int(11) NOT NULL AUTO_INCREMENT,
  `calle` varchar(45) NOT NULL,
  `colonia` varchar(45) NOT NULL,
  `numero` int(11) NOT NULL,
  `municipio` varchar(45) NOT NULL,
  PRIMARY KEY (`id_direccion`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `direccion`
--

LOCK TABLES `direccion` WRITE;
/*!40000 ALTER TABLE `direccion` DISABLE KEYS */;
INSERT INTO `direccion` VALUES (1,'Valle verde','Lindavista',46,'Atizapan'),(2,'Margartitas','Hacienda',102,'Atizapan'),(3,'San Diego de los Padres','Hacienda',28,'Atizapan'),(4,'Jacarandas','Lomas de Atizapan',78,'Atizapan'),(5,'Castillo de Lincoln','Mexico Nuevo',91,'Atizapan');
/*!40000 ALTER TABLE `direccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrediente`
--

DROP TABLE IF EXISTS `ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrediente` (
  `id_ingrediente` int(11) NOT NULL AUTO_INCREMENT,
  `clasificacion` varchar(45) NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  `existencia` int(11) NOT NULL,
  `precio` double NOT NULL,
  PRIMARY KEY (`id_ingrediente`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrediente`
--

LOCK TABLES `ingrediente` WRITE;
/*!40000 ALTER TABLE `ingrediente` DISABLE KEYS */;
INSERT INTO `ingrediente` VALUES (1,'1','Milanesa',20,18),(2,'1','Salchicha',18,12),(3,'1','Jamon',25,9),(4,'1','Bistec',16,20),(5,'1','Pierna',19,18),(6,'1','Chorizo',23,12),(7,'1','Pan',50,1),(8,'2','Quesillo',30,8),(9,'2','Queso Amarillo',21,8),(10,'2','Queso Blanco',27,8),(11,'3','Mayonesa',50,1),(12,'3','Aguacate',14,5),(13,'3','Jitomate',17,4),(14,'3','Rajas',34,3),(15,'3','Chipotle',28,3),(16,'3','Piña',21,3);
/*!40000 ALTER TABLE `ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrediente_torta`
--

DROP TABLE IF EXISTS `ingrediente_torta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrediente_torta` (
  `id_ingrediente` int(11) NOT NULL,
  `id_torta` int(11) NOT NULL,
  PRIMARY KEY (`id_ingrediente`,`id_torta`),
  KEY `fk_ingrediente_torta_ingrediente1_idx` (`id_ingrediente`),
  KEY `fk_ingrediente_torta_torta1_idx` (`id_torta`),
  CONSTRAINT `fk_ingrediente_torta_id_ingrediente` FOREIGN KEY (`id_ingrediente`) REFERENCES `ingrediente` (`id_ingrediente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ingrediente_torta_id_torta` FOREIGN KEY (`id_torta`) REFERENCES `torta` (`id_torta`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrediente_torta`
--

LOCK TABLES `ingrediente_torta` WRITE;
/*!40000 ALTER TABLE `ingrediente_torta` DISABLE KEYS */;
INSERT INTO `ingrediente_torta` VALUES (1,1),(1,3),(1,4),(1,8),(1,14),(1,16),(1,20),(2,1),(2,5),(2,7),(2,8),(2,15),(2,18),(2,22),(3,1),(3,10),(3,11),(3,12),(3,13),(3,14),(3,15),(3,24),(4,2),(5,1),(5,3),(5,6),(5,7),(5,10),(5,11),(5,17),(5,21),(6,1),(6,4),(6,5),(6,6),(6,19),(6,23),(7,1),(7,2),(7,3),(7,4),(7,5),(7,6),(7,7),(7,8),(7,9),(7,10),(7,11),(7,12),(7,13),(7,14),(7,15),(7,16),(7,17),(7,18),(7,19),(7,20),(7,21),(7,22),(7,23),(7,24),(8,1),(8,2),(8,3),(8,4),(8,5),(8,6),(8,7),(8,8),(8,9),(8,11),(8,12),(8,13),(8,14),(8,15),(8,16),(8,17),(8,18),(8,19),(9,1),(9,9),(9,10),(10,1),(10,9),(16,1),(16,2),(16,13);
/*!40000 ALTER TABLE `ingrediente_torta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido`
--

DROP TABLE IF EXISTS `pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido` (
  `id_pedido` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `tipo_pedido` tinyint(1) NOT NULL,
  `tipo_pago` int(11) DEFAULT NULL,
  `promocion` int(11) DEFAULT NULL,
  `total` double DEFAULT NULL,
  PRIMARY KEY (`id_pedido`),
  KEY `fk_pedido_cliente_idx` (`id_cliente`),
  KEY `fk_promocion_id_promocion_idx` (`promocion`),
  CONSTRAINT `fk_pedido_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_promocion_id_promocion` FOREIGN KEY (`promocion`) REFERENCES `promocion` (`id_promocion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido`
--

LOCK TABLES `pedido` WRITE;
/*!40000 ALTER TABLE `pedido` DISABLE KEYS */;
INSERT INTO `pedido` VALUES (1,1,0,0,NULL,NULL),(2,2,1,0,NULL,NULL),(3,3,0,1,1,NULL);
/*!40000 ALTER TABLE `pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promocion`
--

DROP TABLE IF EXISTS `promocion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promocion` (
  `id_promocion` int(11) NOT NULL AUTO_INCREMENT,
  `descuento` int(11) NOT NULL,
  `descripcion` varchar(60) DEFAULT NULL,
  `fecha_limite` varchar(8) DEFAULT NULL,
  `id_cliente` int(11) NOT NULL,
  PRIMARY KEY (`id_promocion`),
  KEY `fk_promocion_cliente1_idx` (`id_cliente`),
  CONSTRAINT `fk_promocion_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promocion`
--

LOCK TABLES `promocion` WRITE;
/*!40000 ALTER TABLE `promocion` DISABLE KEYS */;
INSERT INTO `promocion` VALUES (1,10,'10 pesos de descuento en la siguiente compra',NULL,3),(2,5,'5 pesos de descuento en la siguiente compra',NULL,1);
/*!40000 ALTER TABLE `promocion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tarjeta_credito`
--

DROP TABLE IF EXISTS `tarjeta_credito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tarjeta_credito` (
  `id_cliente` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `numero_tarjeta` varchar(16) DEFAULT NULL,
  `vigencia` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  CONSTRAINT `id_tarjeta_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarjeta_credito`
--

LOCK TABLES `tarjeta_credito` WRITE;
/*!40000 ALTER TABLE `tarjeta_credito` DISABLE KEYS */;
INSERT INTO `tarjeta_credito` VALUES (3,'Alonso Scherer','3452197603757329','10/17');
/*!40000 ALTER TABLE `tarjeta_credito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `torta`
--

DROP TABLE IF EXISTS `torta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `torta` (
  `id_torta` int(11) NOT NULL AUTO_INCREMENT,
  `costo` int(11) NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `calificacion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_torta`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `torta`
--

LOCK TABLES `torta` WRITE;
/*!40000 ALTER TABLE `torta` DISABLE KEYS */;
INSERT INTO `torta` VALUES (1,60,'Campeona',NULL,NULL),(2,42,'Irlandesa',NULL,NULL),(3,40,'Alemana',NULL,NULL),(4,40,'Norteña',NULL,NULL),(5,40,'Española',NULL,NULL),(6,40,'Italiana',NULL,NULL),(7,40,'Veracruzana',NULL,NULL),(8,40,'Michoacana',NULL,NULL),(9,38,'Ratonera',NULL,NULL),(10,38,'Cubana',NULL,NULL),(11,38,'Suiza',NULL,NULL),(12,38,'Oaxaqueña',NULL,NULL),(13,38,'Hawaiiana',NULL,NULL),(14,38,'Holandesa',NULL,NULL),(15,38,'Francesa',NULL,NULL),(16,36,'Milanesa Quesillo',NULL,NULL),(17,36,'Pierna Quesillo',NULL,NULL),(18,34,'Salchicha Quesillo',NULL,NULL),(19,34,'Chorizo Quesillo',NULL,NULL),(20,28,'Milanesa',NULL,NULL),(21,28,'Pierna',NULL,NULL),(22,25,'Salchicha',NULL,NULL),(23,25,'Chorizo',NULL,NULL),(24,25,'Jamon',NULL,NULL);
/*!40000 ALTER TABLE `torta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `torta_pedido`
--

DROP TABLE IF EXISTS `torta_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `torta_pedido` (
  `id_pedido` int(11) NOT NULL,
  `id_torta` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_torta`,`id_pedido`),
  KEY `fk_torta_pedido_pedido_id` (`id_pedido`),
  KEY `fk_torta_pedido_id` (`id_torta`),
  CONSTRAINT `fk_torta_pedido_id_pedido` FOREIGN KEY (`id_pedido`) REFERENCES `pedido` (`id_pedido`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_torta_pedido_id_torta` FOREIGN KEY (`id_torta`) REFERENCES `torta` (`id_torta`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `torta_pedido`
--

LOCK TABLES `torta_pedido` WRITE;
/*!40000 ALTER TABLE `torta_pedido` DISABLE KEYS */;
INSERT INTO `torta_pedido` VALUES (2,1,1),(3,1,1),(3,2,2),(2,3,1),(1,4,2),(3,9,1),(2,13,1);
/*!40000 ALTER TABLE `torta_pedido` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-16 20:41:55
